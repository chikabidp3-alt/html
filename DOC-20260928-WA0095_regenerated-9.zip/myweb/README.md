# Chikabi Phiri Personal Website

ICT251 Web Technologies - Activity 2

## Folder structure

myweb/
├── index.html
├── activity1_backup.html
├── README.md
├── css/
│   └── styles.css
├── images/
│   ├── photo1.jpg
│   ├── photo2.jpg
│   └── photo3.jpg
└── videos/
    ├── intro.mp4
    └── voice.mp3

## Before submission

1. Replace the three photo placeholders with your own allowed photos.
2. Add your 30–60 second introduction video as `videos/intro.mp4`.
3. Add your 15–30 second audio recording as `videos/voice.mp3`.
4. Open `index.html` with VS Code Live Server.
5. Test all navigation links, media players, form validation and phone-size layout.
6. Commit the project to GitHub and submit the repository link as required by the activity.

## Design

The website uses a dark navy, electric blue and cyan palette for strong contrast, with responsive cards, navigation, gallery, media and form components.
